#!/usr/bin/env bash
# يتطلب: Node 18+ و Java 17 و Android SDK (أو Android Studio)
set -e
npm install
[ -d android ] || npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
echo "الملف الناتج: android/app/build/outputs/apk/debug/app-debug.apk"
