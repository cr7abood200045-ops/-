# مهندس المشروع - تطبيق أندرويد

## الطريقة الأسهل: بناء APK عبر GitHub (بدون تثبيت أي شيء)
1. أنشئ حساباً في github.com ثم مستودعاً جديداً (New repository).
2. ارفع محتويات هذا المجلد كاملة (بما فيها المجلد المخفي `.github`).
3. افتح تبويب Actions ← Build APK ← Run workflow.
4. بعد دقائق ادخل على التشغيل المكتمل ونزّل `mohandes-apk` من قسم Artifacts، وبداخله `app-debug.apk`.
5. انقل الملف إلى الهاتف وثبّته (فعّل «التثبيت من مصادر غير معروفة»).

## الطريقة المحلية
`./build-local.sh` (يلزم Node 18+ وJava 17 وAndroid SDK)،
أو شغّل `npm install && npx cap add android && npx cap open android` ثم Build ← Build APK(s) من Android Studio.

التطبيق نفسه في `www/index.html`. أي تعديل عليه يلزمه `npx cap sync android` ثم إعادة البناء.
